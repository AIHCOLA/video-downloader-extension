// 下载页：解析播放列表 → 选择保存位置（File System Access API）→ 流式下载写入 → 结果展示。
//
// E2E 钩子（供 puppeteer 断言，必须保留）：
//   window.__HLS_STATE  { phase, percent, segmentsDone, segmentsTotal, error, done, filename, bytes }
//   window.__HLS_RESULT { done: true, filename, bytes, durationSeconds, muxed, pathHint }（成功后）
//   window.__HLS_START  可编程触发“开始下载”（等价于点击开始按钮）
import { probePlaylist, downloadHls } from '../src/core/index.mjs';
import {
  assemblePositionedChunks,
  buildFilename,
  clampInt,
  describeError,
  formatBandwidth,
  formatBytes,
  formatDuration,
  formatEta,
  formatSpeed,
  parseDownloaderParams,
  parseSeconds,
  phaseLabel,
} from './util.mjs';

const $ = (id) => document.getElementById(id);

const pageParams = parseDownloaderParams(location.search);
const rawUrl = pageParams.url;
const pageTitle = pageParams.title;
const autosave = pageParams.autosave;
const initialFormat = pageParams.format;
const initialConcurrency = pageParams.concurrency;
const initialStart = pageParams.start;
const initialEnd = pageParams.end;

const els = {
  cancel: $('cancel'),
  videoUrl: $('video-url'),
  copyUrl: $('copy-url'),
  pageTitle: $('page-title'),
  infoStatus: $('info-status'),
  infoSegments: $('info-segments'),
  infoDuration: $('info-duration'),
  infoEncryption: $('info-encryption'),
  infoType: $('info-type'),
  infoVariants: $('info-variants'),
  infoError: $('info-error'),
  format: $('format'),
  concurrency: $('concurrency'),
  startInput: $('start-sec'),
  endInput: $('end'),
  saveModeNote: $('save-mode-note'),
  statusBanner: $('status-banner'),
  start: $('start'),
  progressCard: $('progress-card'),
  phaseText: $('phase-text'),
  percentText: $('percent-text'),
  barFill: $('bar-fill'),
  segmentsText: $('segments-text'),
  downloadedText: $('downloaded-text'),
  bytesText: $('bytes-text'),
  speedText: $('speed-text'),
  etaText: $('eta-text'),
  resultCard: $('result-card'),
  resultFilename: $('result-filename'),
  resultSize: $('result-size'),
  resultDuration: $('result-duration'),
  resultResolution: $('result-resolution'),
  resultFormat: $('result-format'),
  resultHint: $('result-hint'),
  again: $('again'),
  logToggle: $('log-toggle'),
  logCount: $('log-count'),
  log: $('log'),
  logChev: $('log-chev'),
};

const state = {
  downloading: false,
  aborter: null,
  probeController: null,
  info: null,
  bytes: 0,
  filename: null,
  blobParts: null,
  usingFsa: false,
  lastProgress: null,
  renderTimer: null,
  logCount: 0,
  startTs: 0,
};

// ---- E2E 钩子（必须在页面加载阶段就存在） ----------------------------------

window.__HLS_STATE = {
  phase: 'idle',
  percent: 0,
  segmentsDone: 0,
  segmentsTotal: 0,
  error: null,
  done: false,
  filename: null,
  bytes: 0,
};
window.__HLS_RESULT = null;
window.__HLS_BLOB_URL = null;
window.__HLS_BLOB_SIZE = 0;
window.__HLS_START = () => startDownload();

// ---- 保存方式 --------------------------------------------------------------

function supportsFsa() {
  return typeof window.showSaveFilePicker === 'function' && window.isSecureContext !== false;
}

function savePickerTypes(outFormat) {
  return outFormat === 'ts'
    ? [{ description: 'TS 视频流', accept: { 'video/mp2t': ['.ts'] } }]
    : [{ description: 'MP4 视频', accept: { 'video/mp4': ['.mp4'] } }];
}

function setState(patch) {
  if (!window.__HLS_STATE || typeof window.__HLS_STATE !== 'object') {
    window.__HLS_STATE = {
      phase: 'idle',
      percent: 0,
      segmentsDone: 0,
      segmentsTotal: 0,
      error: null,
      done: false,
      filename: null,
      bytes: 0,
    };
  }
  Object.assign(window.__HLS_STATE, patch);
}

// ---- 日志 / 提示 -----------------------------------------------------------

function appendLog(level, message) {
  if (!message) return;
  const line = document.createElement('div');
  line.className = 'log-line log-' + (level === 'warn' || level === 'error' ? level : 'info');
  let time = '';
  try {
    time = new Date().toLocaleTimeString('zh-CN', { hour12: false });
  } catch {
    time = '';
  }
  line.textContent = `[${time}] ${message}`;
  els.log.appendChild(line);
  state.logCount += 1;
  while (els.log.childElementCount > 400) {
    const first = els.log.firstElementChild;
    if (!first) break;
    first.remove();
  }
  els.logCount.textContent = `（${state.logCount} 条）`;
  els.log.scrollTop = els.log.scrollHeight;
}

function showBanner(text, kind = 'error') {
  els.statusBanner.textContent = text;
  els.statusBanner.className = `banner ${kind}`;
}

function hideBanner() {
  els.statusBanner.textContent = '';
  els.statusBanner.className = 'banner hidden';
}

// ---- 进度渲染 --------------------------------------------------------------

function scheduleRender() {
  if (state.renderTimer != null) return;
  state.renderTimer = setTimeout(() => {
    state.renderTimer = null;
    renderProgress();
  }, 60);
}

function renderProgress() {
  const snapshot = window.__HLS_STATE;
  const progress = state.lastProgress || {};
  const percent = Math.max(0, Math.min(100, Number(snapshot.percent) || 0));
  els.progressCard.classList.remove('hidden');
  els.percentText.textContent = percent >= 100 ? '100%' : `${percent.toFixed(1)}%`;
  els.barFill.style.width = `${percent}%`;
  els.phaseText.textContent = phaseLabel(snapshot.phase);
  els.segmentsText.textContent = `${snapshot.segmentsDone || 0} / ${snapshot.segmentsTotal || 0}`;
  els.downloadedText.textContent = formatBytes(progress.bytesDownloaded || 0);
  els.bytesText.textContent = formatBytes(snapshot.bytes || 0);
  els.speedText.textContent = formatSpeed(progress.speedBps);
  els.etaText.textContent = formatEta(progress.etaSeconds);
}

function handleProgress(progress) {
  if (!progress) return;
  state.lastProgress = progress;
  const percent = Number(progress.percent);
  setState({
    phase: progress.phase || 'download',
    percent: Number.isFinite(percent) ? Math.max(0, Math.min(100, percent)) : 0,
    segmentsDone: Number(progress.segmentsDone) || 0,
    segmentsTotal: Number(progress.segmentsTotal) || 0,
  });
  scheduleRender();
}

// ---- 播放列表信息 ----------------------------------------------------------

function renderInfo(info) {
  els.infoSegments.textContent = String(info.segments ?? '—');
  els.infoDuration.textContent = formatDuration(info.durationSeconds);
  els.infoEncryption.textContent = info.encrypted
    ? (info.encryptionMethods && info.encryptionMethods.length ? info.encryptionMethods.join(' / ') : '已加密')
    : '未加密';
  els.infoType.textContent = info.isMaster ? '多码率 Master' : info.isLive ? '直播（无 ENDLIST）' : '点播 VOD';
  if (info.isMaster && Array.isArray(info.variants) && info.variants.length) {
    const sorted = info.variants.slice().sort((a, b) => (b.bandwidth || 0) - (a.bandwidth || 0));
    const top = sorted
      .slice(0, 5)
      .map((variant) => `${variant.resolution || '未知'} · ${formatBandwidth(variant.bandwidth)}`);
    els.infoVariants.textContent = `清晰度档位（共 ${sorted.length} 档，默认选最高码率）：${top.join(' / ')}${sorted.length > 5 ? ' …' : ''}`;
    els.infoVariants.classList.remove('hidden');
  } else {
    els.infoVariants.classList.add('hidden');
  }
  els.infoError.classList.add('hidden');
}

function renderInfoError(message) {
  els.infoSegments.textContent = '—';
  els.infoDuration.textContent = '—';
  els.infoEncryption.textContent = '—';
  els.infoType.textContent = '—';
  els.infoVariants.classList.add('hidden');
  els.infoError.textContent = message;
  els.infoError.classList.remove('hidden');
}

async function autoProbe() {
  els.infoStatus.textContent = '解析中…';
  setState({ phase: 'probe' });
  const controller = new AbortController();
  state.probeController = controller;
  const timer = setTimeout(() => controller.abort(), 60000);
  try {
    const info = await probePlaylist(rawUrl, {
      signal: controller.signal,
      onLog: (level, message) => {
        if (level === 'error') appendLog('error', message);
        else if (level === 'warn') appendLog('warn', message);
      },
    });
    state.info = info;
    renderInfo(info);
    els.infoStatus.textContent = '';
    if (!state.downloading) {
      setState({ phase: 'ready', segmentsDone: 0, segmentsTotal: info.segments });
    }
    appendLog(
      'info',
      `播放列表解析完成：${info.segments} 个片段，时长 ${formatDuration(info.durationSeconds)}` +
        (info.encrypted ? `，加密：${(info.encryptionMethods || []).join(' / ') || '已加密'}` : '，未加密')
    );
    if (info.isLive) appendLog('warn', '该播放列表没有 ENDLIST，可能是直播流，录制可能不完整。');
  } catch (err) {
    if (controller.signal.aborted) {
      if (state.downloading) {
        els.infoStatus.textContent = '解析被中断';
        appendLog('warn', '播放列表解析被下载流程中断。');
      } else {
        els.infoStatus.textContent = '解析超时';
        appendLog('error', '播放列表解析超时。');
        showBanner('播放列表解析超时，仍可点击“开始下载”重试（下载时会重新解析）。', 'warn');
        setState({ phase: 'ready', error: '解析超时' });
      }
      return;
    }
    const message = describeError(err);
    state.info = null;
    renderInfoError(message);
    els.infoStatus.textContent = '解析失败';
    appendLog('error', `解析播放列表失败：${message}`);
    setState({ phase: 'ready', error: message });
    showBanner(`播放列表解析失败：${message}。仍可点击“开始下载”重试。`, 'warn');
  } finally {
    clearTimeout(timer);
    if (state.probeController === controller) state.probeController = null;
  }
}

// ---- 下载流程 --------------------------------------------------------------

function setControlsDisabled(disabled) {
  els.format.disabled = disabled;
  els.concurrency.disabled = disabled;
  els.startInput.disabled = disabled;
  els.endInput.disabled = disabled;
}

function resetProgressUI() {
  els.resultCard.classList.add('hidden');
  els.progressCard.classList.remove('hidden');
  els.barFill.className = 'bar-fill';
  els.barFill.style.width = '0%';
  els.percentText.textContent = '0%';
  els.phaseText.textContent = '准备中…';
  els.segmentsText.textContent = '0 / 0';
  els.downloadedText.textContent = '0 B';
  els.bytesText.textContent = '0 B';
  els.speedText.textContent = '—';
  els.etaText.textContent = '—';
}

function resetForRetry() {
  els.resultCard.classList.add('hidden');
  els.progressCard.classList.add('hidden');
  els.barFill.className = 'bar-fill';
  els.barFill.style.width = '0%';
  els.percentText.textContent = '0%';
  els.phaseText.textContent = '等待开始';
  els.segmentsText.textContent = '0 / 0';
  els.downloadedText.textContent = '0 B';
  els.bytesText.textContent = '0 B';
  els.speedText.textContent = '—';
  els.etaText.textContent = '—';
  els.start.textContent = '选择保存位置并开始下载';
  els.start.disabled = false;
  els.cancel.disabled = true;
  hideBanner();
  state.bytes = 0;
  state.filename = null;
  state.lastProgress = null;
  window.__HLS_RESULT = null;
  window.__HLS_BLOB_URL = null;
  window.__HLS_BLOB_SIZE = 0;
  setState({
    phase: 'idle',
    percent: 0,
    segmentsDone: 0,
    segmentsTotal: state.info ? state.info.segments : 0,
    error: null,
    done: false,
    filename: null,
    bytes: 0,
  });
}

/**
 * Blob 降级 / autosave 模式的文件组装。
 *
 * 由于 MP4（fastStart:false）在 finalize 时会按绝对偏移回填文件头部 mdat 的 size，
 * 不能简单把 chunk 依次 push 成一个数组；这里按 { position, data } 收集，
 * 结束后分配最终大小（各段 position + length 的最大值）再按偏移复制。
 */
async function finalizeBlob(chunks, filename, outFormat) {
  const type = outFormat === 'ts' ? 'video/mp2t' : 'video/mp4';
  // 按 position 组装（兼容 MP4 finalize 时对文件头部 mdat size 的回填）。
  const buffer = assemblePositionedChunks(chunks);
  // 释放分段引用，降低峰值内存占用。
  chunks.length = 0;
  const blob = new Blob([buffer], { type });
  const objectUrl = URL.createObjectURL(blob);
  // E2E 辅助钩子：可在页面内 fetch(window.__HLS_BLOB_URL) 直接校验字节内容，
  // 不依赖浏览器的下载目录/下载行为设置。
  window.__HLS_BLOB_URL = objectUrl;
  window.__HLS_BLOB_SIZE = blob.size;
  try {
    const link = document.createElement('a');
    link.href = objectUrl;
    link.download = filename;
    link.rel = 'noopener';
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    link.remove();
  } finally {
    setTimeout(() => URL.revokeObjectURL(objectUrl), 10 * 60 * 1000);
  }
  appendLog('info', `已按偏移组装文件（${formatBytes(blob.size)}），正在交给浏览器保存。`);
  // 给浏览器一点时间真正开始下载，便于调用方/E2E 观察。
  await new Promise((resolve) => setTimeout(resolve, 400));
  return blob.size;
}

function showResult(result, meta) {
  els.resultFilename.textContent = meta.filename;
  els.resultSize.textContent = formatBytes(meta.bytes);
  els.resultDuration.textContent = formatDuration(
    Number(result.durationSeconds) || (state.info && state.info.durationSeconds) || 0
  );
  const width = Number(result.width) || 0;
  const height = Number(result.height) || 0;
  els.resultResolution.textContent = width > 0 && height > 0 ? `${width} × ${height}` : '—';
  els.resultFormat.textContent = meta.outFormat === 'ts' ? 'TS 原始流' : 'MP4（H.264 + AAC）';
  els.resultHint.textContent = `${meta.pathHint} 下载耗时 ${formatDuration(meta.elapsedMs / 1000)}。`;
  els.resultCard.classList.remove('hidden');
}

function updateSaveModeNote() {
  let text;
  if (autosave) {
    text = '自动保存模式（autosave=1）：点击开始后直接下载，完成后自动保存到浏览器下载目录。';
  } else if (supportsFsa()) {
    text = '点击开始后会弹出系统“保存文件”对话框；选择位置后边下载边写入磁盘，不占用大量内存。';
  } else {
    text = '当前环境不支持 File System Access API，会把文件缓存在内存中，完成后通过浏览器下载。大文件可能占用较多内存。';
  }
  els.saveModeNote.textContent = text;
}

function cancelDownload() {
  if (!state.aborter) return;
  els.cancel.disabled = true;
  els.phaseText.textContent = '正在取消…';
  appendLog('warn', '用户请求取消下载…');
  try {
    state.aborter.abort();
  } catch (err) {
    console.warn('[HLS] abort 失败：', err);
  }
}

async function startDownload() {
  if (state.downloading) return;
  if (!rawUrl) {
    showBanner('缺少视频地址（url 参数），无法开始下载。', 'error');
    return;
  }
  if (!/^https?:\/\//i.test(rawUrl)) {
    showBanner('视频地址格式不正确，需要以 http:// 或 https:// 开头。', 'error');
    return;
  }

  const outFormat = els.format.value === 'ts' ? 'ts' : 'mp4';
  const concurrency = clampInt(els.concurrency.value, 16, 1, 64);
  const startSec = parseSeconds(els.startInput.value);
  const endSec = parseSeconds(els.endInput.value);
  if (startSec != null && endSec != null && endSec <= startSec) {
    showBanner('“结束时间”必须大于“开始时间”。', 'error');
    return;
  }

  // 中断尚未完成的自动解析，避免重复请求网络。
  if (state.probeController) {
    try {
      state.probeController.abort();
    } catch {
      /* 忽略 */
    }
    state.probeController = null;
  }

  hideBanner();
  resetProgressUI();
  state.downloading = true;
  state.bytes = 0;
  state.filename = null;
  state.blobParts = null;
  state.usingFsa = false;
  state.lastProgress = null;
  state.startTs = Date.now();
  window.__HLS_RESULT = null;
  window.__HLS_BLOB_URL = null;
  window.__HLS_BLOB_SIZE = 0;
  setState({
    phase: 'download',
    percent: 0,
    segmentsDone: 0,
    segmentsTotal: state.info ? state.info.segments : 0,
    error: null,
    done: false,
    filename: null,
    bytes: 0,
  });
  renderProgress();
  setControlsDisabled(true);
  els.cancel.disabled = false;
  els.start.disabled = true;
  els.start.textContent = '下载中…';

  const controller = new AbortController();
  state.aborter = controller;
  let filename = buildFilename(rawUrl, outFormat);
  let writer = null;
  let blobParts = null;

  try {
    // 1) 选择保存位置（File System Access API），拿到可写流。
    if (!autosave && supportsFsa()) {
      let handle = null;
      try {
        handle = await window.showSaveFilePicker({ suggestedName: filename, types: savePickerTypes(outFormat) });
      } catch (pickerErr) {
        if (pickerErr && pickerErr.name === 'AbortError') {
          appendLog('warn', '已取消选择保存位置。');
          setState({ phase: 'cancelled', done: false, error: '已取消' });
          els.barFill.classList.add('cancelled');
          els.phaseText.textContent = '已取消';
          showBanner('已取消：未选择保存位置。', 'warn');
          return;
        }
        appendLog('warn', `无法打开保存对话框（${describeError(pickerErr)}），改用浏览器下载方式。`);
        handle = null;
      }
      if (handle) {
        writer = await handle.createWritable();
        state.usingFsa = true;
        filename = handle.name || filename;
        appendLog('info', `保存位置已选择：${filename}`);
      }
    }

    if (!writer) {
      blobParts = [];
      state.blobParts = blobParts;
      appendLog(
        'info',
        autosave
          ? '自动保存模式（autosave=1）：完成后自动下载文件。'
          : '当前环境不支持文件选择器，将在下载完成后通过浏览器下载文件。'
      );
    }

    state.filename = filename;
    setState({ filename });

    // 2) 位置感知流式写入。
    //    MP4（fastStart:false，moov 在文件末尾）在 finalize 时会按绝对偏移回填文件头部
    //    mdat 的 size（position≈28），因此 downloadHls 以 (chunk, position) 调用 write：
    //      - position 为数字：写到该绝对偏移（覆盖写，用于回填）；
    //      - position 缺省：顺序追加。
    //    FSA：FileSystemWritableFileStream 原生支持 { type:'write', data, position }；
    //    Blob：先按 {position,data} 收集，完成后按偏移组装（见 finalizeBlob）。
    let sequentialOffset = 0; // 顺序追加的累计偏移
    let positionedSeen = false; // 是否出现过位置写入（出现过则后续“追加”按文件末尾处理）
    let fileSize = 0; // 文件最大范围 = 最终文件大小（含回填，不重复计数）
    const write = async (chunk, position) => {
      if (!chunk) return;
      const bytes = chunk instanceof Uint8Array ? chunk : new Uint8Array(chunk);
      if (!bytes.byteLength) return;
      const hasPosition = Number.isFinite(position);
      let offset;
      if (hasPosition) {
        offset = position;
        positionedSeen = true;
      } else if (positionedSeen) {
        offset = fileSize;
      } else {
        offset = sequentialOffset;
      }
      if (writer) {
        if (hasPosition || positionedSeen) {
          await writer.write({ type: 'write', data: bytes, position: offset });
        } else {
          await writer.write(bytes);
        }
      } else {
        // Blob 模式复制一份，避免上游复用缓冲区。
        blobParts.push({ position: offset, data: bytes.slice() });
      }
      if (!hasPosition) sequentialOffset = offset + bytes.byteLength;
      if (offset + bytes.byteLength > fileSize) fileSize = offset + bytes.byteLength;
      state.bytes = fileSize;
      setState({ bytes: fileSize });
      scheduleRender();
    };

    const result = await downloadHls({
      playlistUrl: rawUrl,
      concurrency,
      start: startSec,
      end: endSec,
      signal: controller.signal,
      output: {
        type: outFormat,
        // 声明支持按文件偏移写入，核心才会使用 fastStart:false（普通渐进式 MP4，moov 在末尾），
        // 并在 finalize 时把 mdat size 回填到文件头部（>4MiB 时必需）。
        supportsPosition: true,
        write,
      },
      onProgress: handleProgress,
      onLog: (level, message) => appendLog(level, message),
    });

    if (writer) {
      await writer.close();
      writer = null;
    }
    if (blobParts) {
      const assembledSize = await finalizeBlob(blobParts, filename, outFormat);
      if (Number.isFinite(assembledSize) && assembledSize > 0) {
        state.bytes = assembledSize;
        setState({ bytes: assembledSize });
      }
      blobParts = null;
      state.blobParts = null;
    }

    const payload = result || {};
    const elapsedMs = Date.now() - state.startTs;
    const segmentsDone = window.__HLS_STATE.segmentsDone || Number(payload.segments) || 0;
    const segmentsTotal = window.__HLS_STATE.segmentsTotal || (state.info ? state.info.segments : segmentsDone);
    const pathHint = state.usingFsa
      ? `已保存到你选择的文件：${filename}`
      : '已通过浏览器下载，请到浏览器下载目录查看（Ctrl+J / chrome://downloads）。';

    setState({
      phase: 'done',
      percent: 100,
      segmentsDone,
      segmentsTotal,
      error: null,
      done: true,
      filename,
      bytes: state.bytes,
    });
    window.__HLS_RESULT = {
      done: true,
      filename,
      bytes: state.bytes,
      durationSeconds: Number(payload.durationSeconds) || 0,
      muxed: Boolean(payload.muxed),
      // moovFront=false 表示普通渐进式 MP4（moov 在文件末尾）；用于 E2E 确认位置感知写入生效。
      moovFront: payload.moovFront === true,
      pathHint,
    };
    els.barFill.classList.add('complete');
    renderProgress();
    showResult(payload, { filename, bytes: state.bytes, pathHint, elapsedMs, outFormat });
    appendLog('info', `下载完成：${filename}，${formatBytes(state.bytes)}，耗时 ${formatDuration(elapsedMs / 1000)}`);
  } catch (err) {
    if (writer) {
      try {
        await writer.abort();
      } catch {
        /* 忽略 */
      }
      writer = null;
    }
    state.blobParts = null;
    blobParts = null;
    const aborted = controller.signal.aborted || (err && err.name === 'AbortError');
    if (aborted) {
      appendLog('warn', '已取消下载，未完成的数据已清理。');
      setState({ phase: 'cancelled', done: false, error: '已取消' });
      els.barFill.classList.add('cancelled');
      els.phaseText.textContent = '已取消';
      showBanner('已取消下载，未完成的数据已清理。', 'warn');
    } else {
      const message = describeError(err);
      appendLog('error', `下载失败：${message}`);
      setState({ phase: 'error', done: false, error: message });
      els.barFill.classList.add('error');
      els.phaseText.textContent = '下载失败';
      showBanner(`下载失败：${message}`, 'error');
    }
  } finally {
    state.downloading = false;
    state.aborter = null;
    setControlsDisabled(false);
    els.cancel.disabled = true;
    els.start.disabled = false;
    els.start.textContent = '重新下载';
    scheduleRender();
  }
}

// ---- 复制 / 事件 / 初始化 --------------------------------------------------

async function copyUrl() {
  const original = els.copyUrl.textContent;
  try {
    if (!navigator.clipboard || typeof navigator.clipboard.writeText !== 'function') {
      throw new Error('clipboard unavailable');
    }
    await navigator.clipboard.writeText(rawUrl);
    els.copyUrl.textContent = '已复制';
    setTimeout(() => {
      els.copyUrl.textContent = original;
    }, 1200);
  } catch {
    showBanner('复制失败，请手动选中地址复制。', 'error');
  }
}

function bindEvents() {
  els.start.addEventListener('click', () => {
    void startDownload();
  });
  els.cancel.addEventListener('click', () => {
    cancelDownload();
  });
  els.again.addEventListener('click', () => {
    resetForRetry();
    void startDownload();
  });
  els.copyUrl.addEventListener('click', () => {
    void copyUrl();
  });
  els.logToggle.addEventListener('click', () => {
    const collapsed = els.log.classList.toggle('collapsed');
    els.logToggle.classList.toggle('collapsed', collapsed);
  });
}

function init() {
  els.videoUrl.textContent = rawUrl || '（未提供视频地址）';
  els.videoUrl.title = rawUrl;
  if (pageTitle) {
    els.pageTitle.textContent = pageTitle;
  } else {
    els.pageTitle.classList.add('hidden');
  }
  els.format.value = initialFormat;
  els.concurrency.value = String(initialConcurrency);
  if (initialStart != null) els.startInput.value = String(initialStart);
  if (initialEnd != null) els.endInput.value = String(initialEnd);
  updateSaveModeNote();
  bindEvents();

  if (!rawUrl) {
    els.infoStatus.textContent = '缺少视频地址';
    els.start.disabled = true;
    els.progressCard.classList.add('hidden');
    showBanner('缺少 url 参数。请从扩展弹窗重新打开本页面，或在页面地址后追加 ?url=<m3u8 地址>。', 'error');
    setState({ phase: 'error', error: '缺少 url 参数' });
    return;
  }
  if (!/^https?:\/\//i.test(rawUrl)) {
    els.infoStatus.textContent = '地址格式不正确';
    els.start.disabled = true;
    els.progressCard.classList.add('hidden');
    showBanner('视频地址格式不正确，需要以 http:// 或 https:// 开头。', 'error');
    setState({ phase: 'error', error: '视频地址格式不正确' });
    return;
  }
  void autoProbe();
}

void init();
