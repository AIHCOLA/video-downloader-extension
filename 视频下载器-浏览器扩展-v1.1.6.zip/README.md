# 视频下载器（浏览器扩展 · Chrome / Edge · Manifest V3）

在浏览器里直接下载网页播放的视频，纯扩展内完成、**不需要安装本地服务端**：

- **HLS（m3u8）**：自动检测 → 并发下载分片 → AES-128 解密 → **直接封装为普通 MP4**（H.264 + AAC，默认）或保留 TS 原始流。
- **B 站（v1.1）**：整段 MP4 直存；1080P 走 DASH 音视频合并，清晰度可选。

- 纯前端、Manifest V3、无远程代码 / 无 CDN / 无 eval / 无 wasm。
- 下载时边下边写盘（File System Access API），不会把整部视频读进内存。
- 支持手动粘贴链接；HLS 支持只下载指定时间段；支持取消下载并清理半成品。

**版本**：1.1.6（当前支持：通用 HLS、B 站；后续版本按 抖音 → 腾讯视频 → 优酷的节奏扩展）


> 1.1.1 / 1.1.2：弹窗只有**一张来源卡**，按当前标签页的链接类型换内容——
> 命中 B 站时标题变「检测到 B站视频」、列表里换成这条视频页链接（可复制、可选中）；
> 其它页面仍是「检测到的 M3U8」+ 候选列表。
>
> 1.1.3：修复 B 站页面没有角标的问题——角标规则统一为「m3u8 候选数优先，站点视频页计 1」；
> 同时补上稍后再看 / 收藏夹 / 活动页等 `/list`、`/medialist` 形式播放页的识别（视频号在 query 里）。
>
> 1.1.4：B 站清晰度上限从 720P 提到 **1080P**——播放地址改为在 B 站页面上下文里请求，带上浏览器里的登录态；
> 未登录仍是 720P。界面上会直接写明「本次清晰度」以及是不是受未登录限制。
>
> 1.1.6：**支持 1080P**。查清了 720P 的真实原因——durl（整段 MP4）通道本身封顶 720P，
> 1080P 只在 DASH 通道且音视频分离；新增 fMP4 解复用 + mp4-muxer 合并（边下边写，不占内存），
> 清晰度下拉按「真实存在的 H.264 轨道」列出，选 1080P 就自动走合并。
>
> 1.1.5：补上 **WBI 签名（w_rid）**——B 站对高清晰度要求签名，只带 Cookie 不够，这也是 1.1.4 仍停在 720P 的原因；
> 同时下载页新增**清晰度下拉**：接口给几档就列几档，切换后即时重新解析（1080P 以上会标明「需 DASH，暂不支持」）。

---

## 一、安装（加载已解压的扩展程序）

1. 打开 Chrome 或 Edge，地址栏进入 `chrome://extensions`（Edge 为 `edge://extensions`）。
2. 打开右上角的 **“开发者模式”** 开关。
3. 点击 **“加载已解压的扩展程序”**，选择本项目里的 **`浏览器扩展/`** 目录（就是包含 `manifest.json` 的那一层）。
4. 扩展列表中出现“HLS 视频下载器”即安装成功；建议把它固定到工具栏（拼图图标 → 图钉）。

> 安装后如果修改了扩展文件，回到 `chrome://extensions` 点击该扩展卡片上的 **刷新（↻）** 按钮即可生效。

**环境要求**：Chrome / Edge 版本 ≥ 116（Manifest V3 + `chrome.storage.session`）。推荐使用较新的正式版。

---

## 二、使用步骤

### 1. 自动检测下载

1. 在视频网站正常播放视频（让页面真正请求到 `.m3u8` 播放列表）。
2. 点击工具栏上的扩展图标，弹窗会列出当前标签页检测到的 m3u8 链接；扩展图标角标上的紫色数字就是候选数量。
3. 在列表中选中一条（默认选中最新一条），可点“复制”。
4. 选择 **输出格式**（MP4 推荐 / TS）和 **并发数**（默认 16，网络好可调高，1–64）。
5. 点击 **“开始下载”**，会打开扩展内的下载页面。
6. 下载页面先自动解析播放列表，显示片段数、总时长、是否加密、清晰度档位；
   点击 **“选择保存位置并开始下载”**，在系统保存对话框里选择位置后开始下载。
7. 下载过程中可以查看进度、速度、剩余时间、日志；随时可以点 **“取消下载”**。
8. 完成后会显示结果卡（文件名、大小、时长、分辨率、保存位置提示），可点“重新下载”。

### 2. 手动粘贴链接下载

在弹窗的“手动输入”里粘贴任意 m3u8 地址 → 点 **“解析”** 先确认信息（片段数 / 时长 / 加密 / 清晰度）→ 点 **“开始下载”**。

### 3. B 站视频（v1.1 新增）

1. 打开任意 B 站视频页（`https://www.bilibili.com/video/BVxxxxxxx`，支持 `?p=2` 指定分 P、`b23.tv/xxx` 短链、`av` 号）。
2. 点击工具栏图标：列表卡标题变成 **「检测到 B站视频」**，列表里就是这条视频页链接（可复制、可选中），扩展图标右下角显示 **1**。
3. 下载页自动解析：标题、UP 主、清晰度、文件大小、时长；确认后点 **「选择保存位置并开始下载」**。
4. **清晰度下拉（v1.1.6）**：下载页有「清晰度」选择框，列出的都是**真的能下到的档位**——
   未登录通常只有 720P / 480P / 360P，登录后有 1080P。切换后立即重新解析，文件大小与文件名一起刷新。
   选 1080P 时会自动走「视频轨 + 音频轨合并」（下载页会提示），低于 720P 的档位能整段直存。
5. 文件按 `标题_BV号[_P2]_1080P.mp4` 命名，保存位置由你在系统对话框里选择。

也可以不打开 B 站页面：在弹窗「手动输入」里粘贴 B 站视频链接 → 点「解析」→ 点「开始下载」。

**B 站下载是怎么走的**（值得知道，因为它决定了失败时的表现）：

| 环节 | 做法 |
| --- | --- |
| 取播放地址 | 公开接口 `x/web-interface/view` + `x/player/wbi/playurl`（带 WBI 签名），同时要 DASH 与 durl 两种格式 |
| 清晰度 | durl 通道**封顶 720P**（这是 1.1.5 之前只有 720P 的真正原因）；1080P 只在 DASH 里。两件事都要：**WBI 签名** + **在 B 站页面上下文里请求**（带登录态） |
| 1080P 下载 | DASH 的视频轨、音频轨分开取，边下边用 mp4-muxer 合并成一个 MP4（不落临时文件、不占整片内存） |
| 直连下载 | 扩展页直接 fetch，配合 `declarativeNetRequest` 静态规则给 CDN 请求补上 `Referer: https://www.bilibili.com`（B 站 CDN 强校验 Referer，缺了就是 403） |
| 直连被拒时 | 自动降级：在任意 B 站标签页（没有就后台开一个 `https://www.bilibili.com/`）里用页面上下文分块取字节，天然带正确 Referer，再回传给扩展写盘 |

不支持的 B 站内容：**番剧/影视等 PGC 页面**（`/bangumi/`）、付费课程、充电专属、SAMPLE-AES / DRM 加密内容。
这些要么需要登录与付费，要么属于版权保护内容，扩展不会绕过。

### 4. 只下载片段区间（可选）

下载页面支持填写“开始（秒）”和“结束（秒）”，例如 `60` / `70` 表示只下载 01:00–01:10 的内容；
留空表示下载整部视频。MP4 输出会按时间戳裁剪到该区间（**仅 HLS 支持；B 站是整段 MP4，不做裁剪**）。

### 5. 下载页 URL 参数（高级 / 自动化）

下载页 `downloader/downloader.html` 支持以下查询参数：

| 参数 | 说明 | 默认 |
| --- | --- | --- |
| `url` | m3u8 地址（必填） | — |
| `format` | `mp4` 或 `ts` | `mp4` |
| `concurrency` | 并发数 1–64 | `16` |
| `start` / `end` | 只下载指定秒区间 | 整部 |
| `title` | 页面标题（仅展示用） | 空 |
| `autosave` | `1` = 跳过保存对话框，完成后用浏览器下载（自动化测试用） | `0` |

例如：

```
chrome-extension://<扩展ID>/downloader/downloader.html?url=https%3A%2F%2Fexample.com%2Findex.m3u8&format=mp4&concurrency=16&autosave=1
```

---

## 三、保存位置说明

- **默认（推荐）**：点击开始后会弹出系统“另存为”对话框（File System Access API），
  由你选择目录和文件名；下载过程中**边下边写入该文件**，不占内存。
- **`autosave=1` 或浏览器不支持 File System Access API 时**：文件先缓冲在内存中，
  完成后通过 `<a download>` 交给浏览器下载，保存到浏览器的默认下载目录
  （可在 Chrome 设置里查看，快捷键 `Ctrl+J` 打开下载内容页）。
- 完成后的结果卡会提示本次文件的保存方式；使用“另存为”时文件名以你选择的为准。
- 扩展**不申请 `downloads` 权限**，不会静默往你的硬盘里写文件。

**默认文件名规则**：`video_<视频标识>.<mp4|ts>`。例如
`https://vv.jisuzyv.com/play/aQWNV05d/index.m3u8` → `video_aQWNV05d.mp4`。
视频标识取 m3u8 路径中 `index.m3u8` 前的一段目录名（没有上级目录时退回域名），只保留字母、数字、下划线、连字符。

---

## 四、常见问题（FAQ）

**Q1：弹窗里检测不到 m3u8 链接？**
A：先让页面真正播放视频（部分网站只有点击播放后才请求 m3u8）；也可以手动粘贴链接。
如果链接是 `blob:` 或经过 MSE 二次封装的，可能拿不到原始 m3u8，可尝试在开发者工具 Network 面板搜索 `.m3u8` 后手动粘贴。

**Q2：下载报错 403 / 401，或提示网络错误？**
A：部分站点对分片请求校验 `Referer` / `Cookie` / 签名有效期。本扩展在扩展页面内发请求，
会带上你当前浏览器的 Cookie，但不会自动伪造 `Referer`；如果站点强校验，请稍后重试或使用站点允许的方式。
另外，m3u8 地址或分片地址带时效签名时，过期后需重新获取链接。

**Q3：提示证书错误 / 连接不安全？**
A：扩展页面会像普通网页一样校验证书。请确认站点证书有效；不要为了绕过而关闭系统校验。

**Q4：下载速度慢 / 进度卡住？**
A：可以适当调高并发数（如 24–32），但过高可能被服务器限速或拒绝；如果某个分片一直失败，
扩展会按指数退避自动重试若干次，仍失败会给出中文错误信息。

**Q5：点“取消下载”后文件还在吗？**
A：取消会中止所有正在进行的请求，并丢弃已写入的数据（“另存为”模式下会中止写入）。
结果会在界面显示 **“已取消”**，并清理未完成的半成品。

**Q6：为什么只支持 VOD（点播）的 AES-128 加密？**
A：直播流没有 `#EXT-X-ENDLIST`，无法确定结尾；SAMPLE-AES / DRM（Widevine 等）属于受保护内容，本扩展不支持且不会绕过 DRM。

**Q7：安装时提示权限很多（读取和更改所有网站上的数据）？**
A：这是 `host_permissions: ["<all_urls>"]`，用于在扩展页面跨域请求任意站点的 m3u8 与分片、以及在 B 站页面里取视频字节，是下载功能的必要条件。
扩展只在检测 m3u8 时被动记录链接，不会注入页面、不修改网页内容。

**Q7b：`declarativeNetRequest` 和 `scripting` 权限是干什么的？**
A：两个都只服务于 B 站：

- `declarativeNetRequest` + `rules/bilibili-referer.json`：给发往 B 站 CDN（bilivideo.com / mountaintoys.cn 等）的请求补 `Referer`。
  规则是**静态、只改请求头**，不改地址、不重定向、不屏蔽任何请求，作用范围仅限上面这几个域名。
- `scripting`：直连被 CDN 拒绝时，到你已打开的 B 站标签页里分块取字节（页面上下文自带合法 Referer）。
  没有 B 站标签页时会后台打开一个 `https://www.bilibili.com/`，用完不会自动关闭。

**Q8：B 站只能下到 720P？**
A：不是。720P 是**未登录**时接口给的上限。扩展会把 `playurl` 请求**放在 B 站页面上下文里发**，
请求天然带上你浏览器里的 B 站登录态，因此：

- 未登录 → 720P / 360P；
- 已登录（免费账号）→ 最高 **1080P**；
- 大会员的 1080P+ / 4K / HDR / 杜比 → 走 **DASH 分离轨道**（音视频两条），当前版本还不能合并，会明确提示。

扩展**不读取、不保存、不转发**任何 Cookie：请求由页面自己发出，扩展只接收“播放地址”这段 JSON。

**Q9：为什么用命令行 `--load-extension` 启动 Chrome 时扩展没加载？**
A：Chrome 137+ 的正式版出于安全考虑限制了命令行加载扩展（`--disable-extensions-except` 会被忽略），
自动化测试请使用 **Chrome for Testing**；普通用户手动“加载已解压的扩展程序”不受影响。

**Q10：下载 MP4 后播放器能播吗？**
A：默认输出是普通渐进式 MP4（moov 在文件末尾），Chrome / Edge / VLC / PotPlayer / ffmpeg 均可正常播放。
如果目标站点原始编码不是 H.264 + AAC，封装结果可能无法播放，此时可改用 TS 原始流输出。

---

## 五、已知限制

**通用**

- **仅支持 HLS（m3u8）与 B 站**；不支持 DASH（mpd）直链、blob: MSE 私有协议（后续版本再扩）。
- 需要 `host_permissions: ["<all_urls>"]` 才能跨域获取播放列表、分片与站点视频字节。
- 浏览器内存/磁盘限制：`autosave`（内存 Blob）模式会在完成后按偏移组装完整文件（峰值内存约为文件大小的 2 倍），
  不适合超长视频；长视频建议使用“另存为”流式写入。
- 扩展不提供任何绕过付费/版权保护的能力，请仅下载你有权保存的内容。

**HLS**

- **仅支持 VOD**（存在 `#EXT-X-ENDLIST`）；直播流可能无法完整下载。
- 加密仅支持 **AES-128**（`#EXT-X-KEY:METHOD=AES-128`）；**SAMPLE-AES / DRM 不支持**。
- 输出为 MP4 时要求源流为 **H.264 视频 + AAC 音频**（TS 分片）；其它编码请选 TS 输出。
- 不支持需要特殊 `Referer` / 自定义请求头强校验的站点。

**B 站（v1.1）**

- 画质上限 **1080P**：1080P 走 DASH 合并；1080P+ / 4K / HDR / 杜比虽然也是 DASH，但大多只有 HEVC/AV1 轨道，
  当前合并器只支持 **H.264**，所以这些档位不会出现在下拉里。
- 清晰度取决于登录态：未登录 720P（durl 封顶），登录后 1080P。扩展不读取、不保存 Cookie，
  只是把接口请求放到 B 站页面里发，让浏览器自己带 Cookie。
- 极少数超长视频的 durl 会被拆成多段；此时会自动改走 DASH 合并，不再报错。
- 不支持 **番剧/影视（PGC）**、付费课程、充电专属、互动视频、SAMPLE-AES/DRM 内容。
- 不支持按时间段裁剪（源文件是整段 MP4，不做重封装）。
- 直连被 CDN 拒绝并降级到标签页代理时，速度受 base64 传输影响，约为直连的 1/2～1/3；
  代理模式需要至少一个可用的 B 站标签页（没有会后台打开一个）。

---

## 六、目录结构

```
浏览器扩展/
├─ manifest.json          # MV3 清单：权限、SW、popup、图标、DNR 规则集
├─ background.js          # Service Worker：webRequest 检测 m3u8、角标、消息 API、设置
├─ rules/
│  └─ bilibili-referer.json  # 静态规则：给 B 站 CDN 请求补 Referer（只改请求头）
├─ popup/                 # 工具栏弹窗：来源卡（m3u8 候选 / B站视频链接，按链接类型切换）、手动解析、设置
├─ downloader/            # 下载页：自动解析、选择保存位置、流式下载、进度/取消/结果
│  └─ util.mjs            # 下载页与弹窗共用的纯逻辑（参数解析/格式化/文件名规则）
├─ src/core/              # 下载核心
│  ├─ index.mjs           #   HLS：探测 + 下载（m3u8 解析、AES-128、TS 解复用、MP4 封装）
│  ├─ direct.mjs          #   直链：整段 MP4 流式写盘 / 分块代理兜底
│  └─ tab-proxy.mjs       #   经 B 站标签页分块取字节（Referer 兜底）
├─ src/sites/             # 站点适配器
│  ├─ index.mjs           #   注册表 + detectSite()
│  └─ bilibili.mjs        #   B 站：URL 解析、view/playurl、清晰度、文件名
├─ lib/mp4-muxer.mjs      # MIT 许可的 MP4 封装库（本地 vendored，无外部依赖）
├─ icons/                 # 16/32/48/128 图标
└─ README.md
```

技术要点：

- 扩展内 `fetch` 分片（受 `host_permissions` 授权跨域），并发下载 + 指数退避重试。
- AES-128 使用 WebCrypto `crypto.subtle.decrypt` 解密，兼容显式 IV 与默认 IV。
- 默认 MP4：TS 解复用出 H.264（Annex-B → AVCC）与 AAC（ADTS → 裸帧），用 mp4-muxer 流式封装；
  采用 `fastStart:false`（moov 在文件末尾的普通渐进式 MP4）。
- **位置感知写入**：MP4 文件超过约 4 MiB 时，封装器会在 finalize 阶段回填文件头部 mdat 的 size，
  因此下载页向核心声明 `output.supportsPosition: true`：FSA 模式用
  `writer.write({ type: 'write', data, position })` 按绝对偏移覆盖写；Blob 降级 / autosave 模式按
  `{position, data}` 收集、完成后按偏移组装再触发下载，保证大文件同样完整可播。
- 下载页通过 File System Access API 的 `showSaveFilePicker` 获取可写流，按序 `write()` 落盘；
  不支持时降级为 Blob + `<a download>`。
- 取消通过 `AbortController` 传递给下载核心；半成品会被清理。
- 自动化测试钩子：页面实时写 `window.__HLS_STATE`，完成后写 `window.__HLS_RESULT`（见下）。
- **B 站直存**：`playurl?fnval=1` 返回的 `durl[0].url` 是**已解复用封装好的整段 MP4**，
  所以下载链路是「Range/流式取字节 → 按序写盘」，不碰 mp4-muxer，也不需要 TS 解复用。
- **Referer 双层方案**：优先 `declarativeNetRequest` 静态规则补 `Referer`（零成本、可流式）；
  一旦拿到 401/403 就自动切到 `chrome.scripting.executeScript({world:'MAIN'})`，
  在 B 站页面上下文里 `fetch` 分块（请求天然带 `Referer` 与 `Origin`，CDN 的 CORS 也放行），
  base64 回传后写盘 —— 代价是带宽放大 1.33 倍，所以只作为兜底。
- **登录态取播放地址**：扩展页到 `api.bilibili.com` 是跨站请求，`SameSite=Lax` 的 SESSDATA 不会带上，
  B 站就只给 720P。所以 `playurl` 同样放进页面上下文里发（同站请求，Cookie 自然带上），
  拿到 1080P 的 `durl` 后仍走原来的直连/代理下载。整个过程中扩展只收到播放地址 JSON，不接触 Cookie。
- **WBI 签名**：B 站对高清晰度还要求 `w_rid`，只有 Cookie 不够。`src/sites/wbi.mjs` 里用纯 JS 实现
  了 MD5（通过 RFC 1321 全部测试向量）与 mixinKey 混淆表，从 `nav` 的 `wbi_img` 取两个 key 后
  对参数签名，再请求 `/x/player/wbi/playurl`；签名被拒（密钥轮换/算法变更）时自动回退普通接口。
- **1080P 合并**：`src/core/fmp4.mjs` 直接解析 `.m4s`（ftyp/moov/sidx/moof/trun），取出每个样本的
  偏移、时长、关键帧标记与 cto；`src/core/dash.mjs` 把两条轨按时间交错喂给 mp4-muxer，
  用 `StreamTarget` 边合并边写盘。内存里只保留当前 fragment（约 1–2 MB），17 分钟的 1080P 也能平稳写完。
- 所有代码为本地 ES Module，无远程加载、无 eval、无 wasm。

---

## 七、开发与自测

本仓库的扩展外壳自测脚本位于 `_extwork/shell-test/`（**不会**打包进扩展）：

| 命令 | 说明 |
| --- | --- |
| `node _extwork/shell-test/run-checks.mjs` | 一键自检：静态检查 + JS 语法 + 纯逻辑单测 + 后台逻辑单测（本机可直接跑，退出码 0 即通过） |
| `node _extwork/shell-test/static-check.mjs` | manifest / HTML / 资源 / 安全项 / id 一致性 / E2E 钩子静态检查 |
| `node _extwork/shell-test/unit-util.mjs` | `downloader/util.mjs` 纯逻辑单测（参数解析、格式化、文件名规则） |
| `node _extwork/shell-test/unit-background.mjs` | 用 chrome.* mock 跑 `background.js`：检测/去重/上限/持久化/角标/消息 API/设置/清理 |
| `node _extwork/shell-test/unit-sites.mjs` | B 站 URL 解析/分 P/清晰度/文件名/错误映射 + `direct.mjs`（流式、403 降级、取消） |
| `node _extwork/shell-test/integration-bilibili.mjs` | 真实网络：解析计划 + 带 Referer 取字节 + 校验无 Referer 被 403 |
| `node _extwork/shell-test/e2e-bilibili-download.mjs` | 端到端：整片下载到本地 + ffmpeg 校验可解码 |
| `node _extwork/shell-test/smoke.mjs` | puppeteer 冒烟测试（需要能正常启动 Chrome 的环境，见下） |

### 自动化测试钩子（供 E2E）

下载页会维护以下全局对象，便于 puppeteer 断言：

```js
window.__HLS_STATE = {
  phase,          // 'idle' | 'probe' | 'download' | 'decrypt' | 'mux' | 'done' | 'error' | 'cancelled' | ...
  percent,        // 0..100
  segmentsDone, segmentsTotal,
  error,          // string | null
  done,           // boolean
  filename,       // string | null
  bytes,          // 已写入文件的字节数
};
window.__HLS_RESULT = { done: true, filename, bytes, durationSeconds, muxed, moovFront, pathHint }; // 成功后才有
//   moovFront=false → 普通渐进式 MP4（moov 在文件末尾），说明位置感知写入已生效；
//   moovFront=true  → 分片式 MP4（fragmented，moov 在文件开头）。
window.__HLS_BLOB_URL;   // 仅 autosave/Blob 模式：完成后可用 fetch(url) 直接取回文件字节做校验
window.__HLS_BLOB_SIZE;  // 仅 autosave/Blob 模式：Blob 字节数（应等于 __HLS_RESULT.bytes）
window.__HLS_START(); // 可编程触发“开始下载”（等价于点击 #start）
```

关键页面元素（E2E 选择器）：开始按钮 `#start`、取消按钮 `#cancel`、开始/结束秒输入框 `#start-sec` / `#end`、
格式选择 `#format`、并发数 `#concurrency`；候选/进度/结果分别由 `#candidates`、`#progress-card`、`#result-card` 呈现。

`puppeteer` 冒烟测试（`_extwork/shell-test/smoke.mjs`）会加载扩展、打开 popup 与 downloader 页面、
校验 manifest 与后台消息 API、并用本地 HTTP 服务验证 m3u8 检测链路。

> ⚠️ 注意：当前开发环境的 DSH 沙箱禁止创建命名管道，Chromium/Chrome 在沙箱内会
> `FATAL: mojo platform_channel` 退出，因此 `smoke.mjs` 无法在该沙箱内运行；
> 请在普通桌面环境或使用 **Chrome for Testing** 运行它。

---

## 八、已验证

> 本结构预留给最终集成结果。以下内容按“验证环境 → 验证项 → 结论”记录。

### 8.1 本地静态 / 单元自检（已完成）

- 环境：Windows + Node v20.19.0（DSH 沙箱，无法启动浏览器）。
- 命令：`node _extwork/shell-test/run-checks.mjs`。
- 结果：静态检查全部通过；`background.js`、`popup.js`、`downloader.js`、`util.mjs` 均通过 `node --check`；
  `util.mjs` 纯逻辑单测（55 项）与 `background.js` 逻辑单测（36 项）全部通过（详见 `_extwork/shell-test/` 输出）。
- 覆盖：manifest 字段与权限、HTML 资源/无重复 id/无内联脚本、无远程代码/eval/wasm、
  E2E 钩子字段、m3u8 检测与消息 API、设置读写、候选去重/上限/清理。

### 8.1b shell ↔ core 集成 / 位置感知写入回归检查（已完成）

- 环境：Windows + Node v20.19.0，真实网络、真实目标流（无需浏览器）。
- 命令：`node _extwork/shell-test/integration-core.mjs`。
- 结果（共 61 项断言全部通过）：
  - `probePlaylist`：1309 个分片 / 4988.667 秒 / AES-128 / VOD，字段与 CONTRACT §3.1 一致。
  - **MP4 位置感知写入回归（>4MiB）**：以 `output.supportsPosition:true` + `write(chunk, position)` 下载 60–70 秒，
    产出 **4.06 MiB**（>4MiB，触发 mdat size 回填）、`moovFront=false`（普通渐进式，moov 在末尾）、
    ffmpeg 校验 `Duration=10.01s`、`Video: h264 (High)`（1920×1080）、`Audio: aac 48000 Hz, stereo`，
    且 `ffmpeg -v error -i 文件 -f null -` **无任何 stderr 输出**（解码零错误）。
  - 小片段对照（<4MiB）：60–62 秒 → 0.83 MiB / Duration 1.97s / 解码零错误。
  - TS 输出：60–70 秒 → 4.60 MiB / mpegts / h264 + aac 48kHz stereo / 解码零错误。
  - 取消：`AbortController` → 抛出 `AbortError`，30 秒内停止，取消后无写入。

### 8.2 真实浏览器 E2E（已完成，全部通过）

- 环境：Windows + **Chrome for Testing 157.0.8103.38**（headless=new）+ puppeteer-core 24.43.1；
  扩展通过 `--load-extension` 加载（扩展 ID `ejbeiclmpfhpkgimhjfjgdffnncoabaf`）。
- 命令：`node _extwork/e2e/run-e2e.mjs`（需在能正常启动 Chrome 的桌面环境运行；本机 DSH 沙箱禁止命名管道，无法在沙箱内跑）。
- 结果：**0 失败**。覆盖与关键数据：
  - 扩展加载 + Service Worker 正常；popup 页面打开无 JavaScript 错误。
  - 打开真实播放页后 **webRequest 自动检测到 m3u8** 并写入候选（`chrome.storage.session`）。
  - 下载页自动解析：**1309 片段 / 01:23:09 / AES-128 / 点播 VOD**。
  - **MP4（0–10 秒）**：920,307 字节，`__HLS_RESULT.durationSeconds=10.003`、`muxed=true`、`moovFront=false`；
    ffmpeg：`Duration 10.00s`、`Video: h264 (High) 1920×1080 24fps`、`Audio: aac 48000 Hz stereo`、
    `ffmpeg -v error -f null -` **解码零错误**；文件结构 `ftyp@4 / mdat@28 / moov@914261`（moov 在末尾，mdat size 回填值正确）。
  - **MP4（60–70 秒，>4 MiB 位置回填回归）**：4,257,633 字节（>4 MiB，触发分块 flush 与 mdat size 回填）、
    `Duration 10.01s`、h264 1920×1080 + aac 48kHz stereo、解码零错误、`moov@4251635` 在 `mdat` 之后。
  - **TS（0–6 秒）**：1,081,940 字节，ffmpeg 解析为 `mpegts + h264 + aac 48kHz stereo`、解码零错误
    （TS 输出按分片边界、不做时间裁剪，因此时长 10.85s 属设计行为）。
  - **取消**：下载中点击“取消下载” → `phase='cancelled'`、页面显示“已取消”、无成功结果、无残留文件。
  - 说明：E2E 在 headless 下通过页面内 `fetch(window.__HLS_BLOB_URL)` 取回产物字节，经本地回环服务落盘后
    用 ffmpeg 校验（headless 浏览器不会把 `<a download>` 落盘，因此以字节内容为准；真实桌面浏览器走
    “另存为”流式写入或浏览器下载目录）。证据保留在 `_extwork/e2e/uploaded/` 与 `_extwork/e2e/screenshots/`。

![下载页完成态（60–70 秒 MP4）](screenshots/downloader-mp4-60-70-done.png)

### 8.3 手动验证步骤（用户可自行复现）

1. 按第一节安装扩展，确认扩展详情页无错误。
2. 打开一个 HLS 视频页面并播放几秒，点击扩展图标，确认列表出现 m3u8、角标数字正确。
3. 选择一条，点“开始下载”，确认下载页显示片段数/时长/加密信息。
4. 点击“选择保存位置并开始下载”，选择桌面上的一个文件，观察进度条、速度、ETA 变化；
   下载中点击“取消下载”，确认提示“已取消”且目标位置没有留下损坏文件。
5. 重新下载并等待完成，确认结果卡信息正确，文件能被播放器打开。
6. 在弹窗手动粘贴同一个 m3u8，点“解析”，确认信息与自动检测一致。
7. 用下载页的“开始/结束（秒）”各填 60/70，确认得到约 10 秒的视频。
8. **B 站**：打开任意视频页 → 弹窗标题应变为「B站视频」且列表里是这条视频链接 → 点「开始下载」→ 确认显示标题/清晰度/文件大小 →
   开始下载，完成后用播放器确认能正常播放（重点看下载开始后日志里是否出现「直连被源站拒绝…改用标签页代理」，
   出现即说明 DNR 规则在你的浏览器上没有生效，但兜底路径仍然可用）。

### 8.4 v1.1（B 站）验证记录

- **静态/单测**（`node _extwork/shell-test/run-checks.mjs`，退出码 0）：
  静态检查 **184 项**（含 manifest 权限、DNR 规则文件存在且只改请求头、新文件无 eval/远程引用）；
  `util.mjs` 61 项、`background.js` 45 项、`unit-sites.mjs` **93 项**，失败 0。
- **真实网络集成**（`integration-bilibili.mjs`，退出码 0，共 **14 项**）：
  - 解析 `BV1GbWq6HEct` → 标题、BV 号、720P(qn=64)、17.6 MB、109.1s、CDN 域名 `*.mountaintoys.cn`；
  - **WBI 签名被接口接受**：`/x/player/wbi/playurl?…&w_rid=…` 返回 code 0，没有触发「回退普通接口」；
  - 带 `Referer` 取首 64 KiB → **HTTP 206**，内容含 `ftyp`（`video/mp4`），
    `Content-Range` 总大小 **18,504,312** 与接口声明完全一致；
  - 不带 `Referer` → **HTTP 403**（这条同时证明了为什么需要 DNR 规则 / 标签页代理）。
- **端到端整片下载**（`e2e-bilibili-download.mjs`，真实 CDN、真实分块写入）：
  - 产出 `假⚡️面⚡️难⚡️藏⚡️泪_BV1GbWq6HEct_720P.mp4`，**18,504,312 字节**（与计划逐字节一致），5 块 × 4 MiB，15.5s；
  - ffmpeg：`Duration 00:01:49.14`、`Video: h264 (High) 1280x720 30fps`、`Audio: aac 48000 Hz stereo`，
    `ffmpeg -v error -i 文件 -f null -` **无任何输出**（解码零错误）。
- **1080P DASH 合并（v1.1.6）**：`e2e-bilibili-1080.mjs` 用真实接口解析出 1080P 轨道并合并，
  产物 `1920x1080 / H.264 High / AAC 48kHz stereo / 00:01:49.23`，ffmpeg 解码零错误；
  视频 3274 帧 + 音频 5116 帧交错写入，36,468,824 字节，全程内存只保留当前 fragment。
  单测另外覆盖：DASH 优先选 AVC 轨道、音频选最高码率、`durlQn === 选中档` 时走整段直存、
  只有 DASH 时也能下、无 AVC 轨道时明确报错。
- **1080P 登录态 + WBI 链路（v1.1.4 / v1.1.5）**：单测覆盖「页面上下文返回 1080P → 计划取 1080P」、
  「页面上下文异常 → 回退匿名 720P」、「只有 DASH 轨道 → 明确报错」、「有 WBI 密钥 → 改走 wbi/playurl 且带 w_rid」、
  「MD5 对齐 RFC 1321 全部向量」、「清晰度选项排序与可用性标记」；
  `api.bilibili.com` 对 `Origin: https://www.bilibili.com` 返回 `Access-Control-Allow-Origin` +
  `Allow-Credentials: true`（curl 实测）；**WBI 签名已在真实接口上被接受**。
  **真实 1080P 效果需在已登录 B 站的浏览器里确认**——本机没有你的登录态，无法代跑。
- **未覆盖**：浏览器内的 DNR / `scripting` 注入链路需要能加载扩展的真实浏览器；
  当前环境的 Chrome 137+ 与 Edge 157 均拒绝命令行 `--load-extension`（`ProcessSingleton` 也被沙箱拦住），
  因此这两条路径以「HTTP 层已证明可行 + 代码静态自检通过」为准，需在普通桌面浏览器里做一次手动确认（见 §8.3 第 1、2 步 + 下载一个 B 站视频）。

## 九、免责声明

本扩展仅供个人备份与学习研究使用。请遵守目标网站的服务条款与当地法律法规，
仅下载你有权保存的内容，不要用于侵犯版权或绕过付费/授权机制。
